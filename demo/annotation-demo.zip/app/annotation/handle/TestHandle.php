<?php

/**
 * Created by PhpStorm.
 * User: LinFei
 * Created time 2022/10/09 9:42:46
 * E-mail: fly@eyabc.cn
 */
declare (strict_types=1);

namespace app\annotation\handle;

use LinFly\Annotation\Interfaces\IAnnotationHandle;

class TestHandle implements IAnnotationHandle
{
    public static function handle(array $item): void
    {
        switch ($item['type']) {
            case 'class':
            case 'method':
                var_dump($item['type'] . ' -> ' . $item['class']);
                break;
        }
    }
}
