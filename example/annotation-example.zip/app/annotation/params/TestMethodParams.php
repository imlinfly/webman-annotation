<?php

/**
 * Created by PhpStorm.
 * User: LinFei
 * Created time 2022/10/09 9:33:43
 * E-mail: fly@eyabc.cn
 */
declare (strict_types=1);

namespace app\annotation\params;

use Doctrine\Common\Annotations\Annotation\Target;
use LinFly\Annotation\AbstractAnnotation;

/**
 * @Annotation
 * @Target({"METHOD"})
 */
#[\Attribute(\Attribute::TARGET_METHOD)]
class TestMethodParams extends AbstractAnnotation
{
    /**
     * 第一个参数必须包含array类型，用来接收注解的参数
     * @param string|array $method
     */
    public function __construct(public string|array $method = '')
    {
        $this->paresArgs(func_get_args(), 'method');
    }
}
