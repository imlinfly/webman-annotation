<?php

namespace app\controller;

use app\annotation\params\TestControllerParams;
use app\annotation\params\TestMethodParams;
use LinFly\Annotation\Annotation;
use LinFly\Annotation\Route\Controller;
use LinFly\Annotation\Route\Route;
use support\Request;

/**
 * @Controller(prefix="annotation/test")
 *
 * 自定义类的注解类
 * @TestControllerParams(controller=IndexController::class)
 */
// PHP8原生注解
// #[Controller(prefix: "annotation/test")]
// #[TestControllerParams(controller: IndexController::class)]
class IndexController
{
    /**
     * @Route(path="/")
     * @access public
     * @return \support\Response
     */
    public function index()
    {
        return redirect(route('api'));
    }

    /**
     * 自定义方法的注解类
     * @Route(path="api", name="api")
     * @TestMethodParams(method="index")
     */
    // PHP8原生注解
    // #[Route(path: 'api', name: 'api')]
    // #[TestMethodParams(method: __METHOD__)]
    public function api(Request $request)
    {
        // 获取指定类的注解列表 包括：类注解、属性注解、方法注解、方法参数注解
        $generator = Annotation::yieldParseClassAnnotations(IndexController::class);

        /**
         * @var string $annotationName 注解类类名
         * @var array $items 注解类参数列表
         */
        foreach ($generator as $annotationName => $items) {
            switch ($annotationName) {
                case TestControllerParams::class:
                case TestMethodParams::class:
                    foreach ($items as $item) {
                        var_dump($item['type'] . ' -> ' . $item['annotation']);
                    }
                    break;
            }
        }
        return response('hello webman');
    }
}
